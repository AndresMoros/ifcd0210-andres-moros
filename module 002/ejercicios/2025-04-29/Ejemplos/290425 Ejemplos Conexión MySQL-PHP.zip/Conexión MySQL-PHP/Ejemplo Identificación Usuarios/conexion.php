


	<?php
	
	/*Datos conexión.*/
	/*
		$user = "root";
		$pass = "";
		$host = "localhost";
		$host = "localhost:3310"; // Servidor con número de puerto si el puerto predeterminado para MySQL (3306), lo está utilizando otra aplicación.
		$base = "usuarios";
	*/
	/*Conexión a la base de datos.*/
	
		//$conexion = mysqli_connect($host, $user, $pass, $base);
		$conexion = mysqli_connect("localhost", "root", "", "usuarios");
		//$conexion = mysqli_connect("localhost:3310", "root", "", "usuarios");
	
	
	?>
	
