<!DOCTYPE html>
<html lang="es">

	<head>
		<title>Archivos 2 | PHP</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/estilos_archivos2.css">
	</head>
	
	<body>
		
		<?php
		
		/* Ejercicio 1. */
			/* Vamos a utilizar el modo de apertura w que nos asegura que siempre vamos a tener un archivo en el que escribir, ya que w si el archivo no existe lo crea. De esta manera, no tendremos que hacer una comprobación previa de la existencia. */
			$archivo = fopen("texto.txt", "w");
			
			/* El proceso de escritura se realiza a través de la función fwrite(). */
			fwrite($archivo, "Hola mundo." . PHP_EOL);
			fwrite($archivo, "Adiós mundo cruel." . PHP_EOL);
			fwrite($archivo, "Hasta luego, Lucas." . PHP_EOL);
			
			/* No nos olvidemos de cerrar una vez terminado el trabajo. */
			fclose($archivo);
			
			/* Luego, volvemos a abrir el archivo para añadir, en lugar de sobrescribir. */
			$archivo = fopen("texto.txt", "a");
			fwrite($archivo, "Texto añadido." . PHP_EOL);
			fclose($archivo);
			
			/* Mostramos un mensaje indicando el éxito de la operación. */
		?>
			
		
		<div id ="contenedor">
			<div class ="ejercicios">
				<h2>Ejercicio 1 Archivos 2</h2>
				<p>El archivo se generó con éxito.</p>
			</div>
		
		<?php
			
		/* Ejercicio 2. */
				/* Pretendemos leer un archivo de texto y crear una copia mediante operaciones de escritura. */
				
				/* Vamos a abrir los dos archivos para poder trabajar simultáneamente con ellos. La apertura para lectura requiere una comprobación. Creamos variables para manejar las rutas de lectura y escritura. */
				$lectura = "lista.txt";
				$escritura = "copia.txt";
				
				if ( !file_exists( $lectura ) ) {
					?>
					<p>Error. No se pudo encontrar el archivo para su lectura.</p>
					<?php
				} else {
					$origen = fopen( $lectura, "r" );
					$destino = fopen( $escritura, "w" );
					
					/* Leemos el archivo de origen. */
					while ( !feof($origen) ) {
						/* Leemos una línea. */
						$linea = fgets($origen);
						/* Y la escribimos en el archivo de destino. Aquí no hace falta PHP_EOL puesto que ya leemos del archivo de origen cada línea con su correspondiente salto de línea */
						fwrite( $destino, $linea );
					}
					
					/* Cerramos los archivos. */
					fclose($destino);
					fclose($origen);
					
					/* También podríamos copiar directamente el archivo con copy(). */
					copy( $lectura, "copia2.txt");
				}
				
				?>
		
			<div class ="ejercicios">
				<h2>Ejercicio 2 Archivos 2</h2>	
				<p>El archivo se copió con éxito.</p>
			</div>
		<?php
			/* Ejercicio 3. */

			$fichero1 = "copia.txt";
			
			if (!file_exists( $fichero1 ) )
			{
				?>
				<p>Error. No se pudo encontrar el archivo para su lectura.</p>
				<?php
			}
			else
			{
				$fichero1_abierto = fopen($fichero1, "r");
				?>
				<div class ="ejercicios">
					<h2>Ejercicio 3 Archivos 2 Variante 1</h2>
				<?php	
				while (!feof($fichero1_abierto))
				{
					$linea1 = fgets($fichero1_abierto);
				?>
					<p><?php echo $linea1 ?></p>
				<?php	
				}

				fclose($fichero1_abierto);
				?>
				</div>
				<?php
			}

			?>
			<?php
			/* Ejercicio 4. */

			$fichero2 = "copia.txt";
			
			if (!file_exists( $fichero2 ) )
			{
				?>
				<p>Error. No se pudo encontrar el archivo para su lectura.</p>
				<?php
			}
			else
			{
				$fichero2_abierto = fopen($fichero2, "r");
				?>
				<div class ="ejercicios">
					<h2>Ejercicio 3 Archivos 2 Variante 2</h2>
					<p><?php echo fread($fichero2_abierto,filesize("copia.txt")) ?></p>
				<?php	
				fclose($fichero2_abierto);
				?>
				</div>
				<?php
			}

			?>
		</div>
	</body>
	
</html>