<?php
    

               $valores = array(2,4,6,8,10);
               

     // Ejecución en una terminal:
            // phpunit --bootstrap arrays0.php arrays0_test.php

  
?>